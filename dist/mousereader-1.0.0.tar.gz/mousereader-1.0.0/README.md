# mousereader
 Python Package for reading MOUSE result files

<b>To install:</b>

```
python -m pip install https://github.com/enielsen93/mousereader/tarball/master
```
