# mousereader
 Python Package for reading MOUSE result files
